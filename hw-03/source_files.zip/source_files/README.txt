This is a Video Rental Simulation program that utilizes package private classes to interact with each other.
The program is able to check in and check out videos as well as check inventory and other functionality.

To Run:
java Main.java pop
or 
java Main.java text

running without an argument will give a prompt that pop or text needs to be in the argument.

Running the program with "pop" will display the Video Rental program with UI in a GUI.
Running with "text" will run the program in the unix shell.

User enters a number that corresponds to a command and it will be displayed in the program.
package shop.ui;

public interface UIPair <P,T>{
	public P getP();
	public T getT();
}
